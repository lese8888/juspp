
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY")
)

def analyze_news(title, summary):
    prompt = f'''
    你是专业游戏行业分析师。

    请分析以下资讯：

    标题：
    {title}

    内容：
    {summary}

    输出：
    1. 50字总结
    2. 热度评级
    3. 玩家情绪
    4. 是否适合做短视频
    '''

    try:
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )

        return response.choices[0].message.content

    except Exception as e:
        return f"AI分析失败: {str(e)}"
