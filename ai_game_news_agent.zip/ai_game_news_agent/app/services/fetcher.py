
import feedparser

RSS_FEEDS = [
    "https://www.ign.com/rss",
    "https://www.gamespot.com/feeds/mashup/",
    "https://kotaku.com/rss"
]

def fetch_news():
    all_articles = []

    for url in RSS_FEEDS:
        feed = feedparser.parse(url)

        for entry in feed.entries[:5]:
            all_articles.append({
                "title": entry.get("title", ""),
                "summary": entry.get("summary", ""),
                "link": entry.get("link", "")
            })

    return all_articles
