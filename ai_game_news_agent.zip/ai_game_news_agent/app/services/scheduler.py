
import threading
import time
from app.services.fetcher import fetch_news

def worker():
    while True:
        articles = fetch_news()

        print(f"抓取到 {len(articles)} 条游戏资讯")

        time.sleep(3600)

def start_scheduler():
    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
