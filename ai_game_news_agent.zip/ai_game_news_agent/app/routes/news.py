
from fastapi import APIRouter
from app.services.fetcher import fetch_news
from app.services.ai_analyzer import analyze_news

router = APIRouter(prefix="/news", tags=["news"])

@router.get("/")
def get_news():
    articles = fetch_news()

    result = []

    for item in articles[:10]:
        analysis = analyze_news(item["title"], item["summary"])

        result.append({
            "title": item["title"],
            "link": item["link"],
            "summary": item["summary"],
            "ai_analysis": analysis
        })

    return result
