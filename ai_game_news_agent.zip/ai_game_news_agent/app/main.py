
from fastapi import FastAPI
from app.routes.news import router as news_router
from app.services.scheduler import start_scheduler

app = FastAPI(title="AI 游戏资讯情报 Agent")

app.include_router(news_router)

@app.on_event("startup")
async def startup():
    start_scheduler()

@app.get("/")
def root():
    return {
        "message": "AI Game News Agent Running"
    }
