
# AI 游戏资讯情报 Agent

一个基于 FastAPI + OpenAI 的游戏资讯情报系统，支持：

- 自动抓取游戏新闻 RSS
- AI 摘要
- 热点分析
- 标签分类
- Discord / Telegram 推送
- REST API
- 前端 Dashboard（简单版）

## 启动

```bash
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

打开：

http://127.0.0.1:8000/docs

## 环境变量

在 `.env` 中填写：

```env
OPENAI_API_KEY=你的key
```

## 推荐扩展

- 接入 Reddit
- 接入 Steam API
- 接入 Twitter/X
- 向量数据库
- 自动视频脚本生成
